export default function Footer() {

    return (<footer>
        <div>&copy; Copyright | Rayane Badaoui | University of Ottawa</div>
    </footer>)
}