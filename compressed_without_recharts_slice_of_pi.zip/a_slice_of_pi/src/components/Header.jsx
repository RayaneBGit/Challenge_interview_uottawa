import Menu from "./Menu"

import stylesLayout from '../styles/Layout.module.css';

export default function Header() {
    return (
        <header className={stylesLayout.header}>
            <Menu></Menu>
        </header>
    )
}