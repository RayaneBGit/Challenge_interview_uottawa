import React, { useState } from 'react';
import datapricing from '../data/pricing_data.json';
import dataorder from '../data/order_data.json';
import stylePricing from '../styles/Pricing.module.css';
import { VictoryChart, VictoryLine, VictoryAxis, VictoryLabel } from 'victory';
export default function Home() {
 
    let all_monthsSet = new Set(dataorder.map((order) => {
        return order.date.substring(5, 7)
    }));

    let all_monthsList = Array.from(all_monthsSet);

    let data_orders_all_items = dataorder.map((order) => ({
        items: order.items,
        month: order.date.substring(5, 7),
        date: order.date
    }));

    let list_price_per_month = all_monthsList.map((month) => ({
        x: month,
    }))


    data_orders_all_items.sort((a, b) => {
        const month1 = parseInt(a.month, 10);
        const month2 = parseInt(b.month, 10);

        if (month1 < month2) {
            return -1;
        } else if (month1 > month2) {
            return 1;
        } else { return 0; }
    })

    const listePricing = Object.entries(datapricing);



    //sum money made per month 
    function calculateMoneyPerMonth(month,data) {
        let sumTotalMonth = 0;
        for (let i = 0; i < data.length; i++) {
            let sumPartMonth = 0
            if (data[i].month === month) {
                for (let j = 0; j < data[i].items.length; j++) {
                    for (let k = 0; k < listePricing.length; k++) {
                        if (data[i].items[j].type === listePricing[k][0]) {
                            if (data[i].items[j].size === "L") {
                                sumPartMonth += listePricing[k][1].L;
                            } else if (data[i].items[j].size === "M") {
                                sumPartMonth += listePricing[k][1].M;
                            } else if (data[i].items[j].size === "S") {
                                sumPartMonth += listePricing[k][1].S;
                            }
                        }

                    }
                }

            }
            sumTotalMonth += sumPartMonth
        }
        return sumTotalMonth;
    }
    function calculateMoneyAllMonth(list_price_per_month, all_monthsList,data_orders) {
        let sum = 0;
        for (let indexMonth = 0; indexMonth < all_monthsList.length; indexMonth++) {
            let sumMonth = calculateMoneyPerMonth(all_monthsList[indexMonth],data_orders);
            list_price_per_month[indexMonth].y = sumMonth;
            sum += sumMonth;
        }
        console.log("S = " + sum);

        console.log(list_price_per_month);

        return [list_price_per_month, sum];
    }

    const data = calculateMoneyAllMonth(list_price_per_month, all_monthsList,data_orders_all_items)[0];

    //first default value
    const [finalData, setFinalData] = useState(data);

    let sum = calculateMoneyAllMonth(list_price_per_month, all_monthsList,data_orders_all_items)[1];

    function filterDates() {
        let startDate = document.getElementById("startDate").value;
        let endDate = document.getElementById("endDate").value;

        let data_filtered_by_date ;

        if ((endDate === "" && startDate === "")) {
            data_filtered_by_date = data_orders_all_items;
        } else if(endDate === ""){
            data_filtered_by_date = data_orders_all_items.filter((element)=> element.date >= startDate);
        }else if (startDate === "") {
            data_filtered_by_date = data_orders_all_items.filter((element) => element.date <= endDate)
        } else {
            data_filtered_by_date = data_orders_all_items.filter((element) =>element.date >= startDate && element.date <= endDate)
        }
        setFinalData(calculateMoneyAllMonth(list_price_per_month, all_monthsList,data_filtered_by_date)[0]);
    }
    return <>
        <main>
            <h1>Pricing</h1>
            <h2>Total revenue in 2023</h2>
            <div className={stylePricing.bar_container} id="container_id">
                <div className="divmoney">
                    <p className="written_money">?</p>
                </div>
                <button className={stylePricing.button_open} onClick={(event) => {
                    let container_id = document.getElementById("container_id");
                    let moneydiv = document.querySelector(".divmoney");
                    let moneyp = moneydiv.querySelector(".written_money");
                    let newmoneyp = document.createElement("p");
                    newmoneyp.textContent = sum + "$"
                    moneydiv.style.backgroundColor = "green";
                    moneydiv.style.marginLeft = "1.1rem";
                    moneydiv.style.marginRight = "1.1rem";
                    moneydiv.style.marginTop = "7.1rem";
                    //I had access to container_id because i had wanted to change the background color when clicking
                    container_id.style.backgroundColor = "rgb(120,120,120)"
                    let buttonelement = event.target;
                    buttonelement.hidden = true;
                    moneydiv.removeChild(moneyp)
                    moneydiv.appendChild(newmoneyp)
                }}>Open</button>

            </div>
            <h2>Revenue per month in 2023</h2>
            <div>
                <form>
                    <label htmlFor="startDate">Start date :</label>
                    <input type="date" id="startDate" name="startDate" />

                    <label htmlFor="endDate">End date :</label>
                    <input type="date" id="endDate" name="endDate" />

                    <button type="button" onClick={filterDates} >Filter</button>
                </form>
            </div>
            <div className={stylePricing.divChartLine}>
                <VictoryChart width={300}
                    height={200} >
                    <VictoryLine data={finalData} style={{
                        data: { fill: 'rgb(255, 209, 135)', stroke: 'rgb(255, 209, 135)', strokeWidth: 2 },
                    }} />
                    {/*axis label est pour les noms d axes et ticklabel est pour les valeurs des axes */}
                    <VictoryAxis style={{ axisLabel: { padding: 30, fill: "green" }, tickLabels: { fill: 'red' }, }} label="Months" />
                    <VictoryAxis style={{ axisLabel: { padding: 35, fill: "green" }, tickLabels: { fill: 'red' }, }} dependentAxis label="Revenue" />

                </VictoryChart>
            </div>
        </main>
    </>
}