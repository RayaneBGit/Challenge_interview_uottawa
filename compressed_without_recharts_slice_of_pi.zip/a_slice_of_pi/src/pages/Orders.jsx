
import React from 'react';
import {
    XYPlot,
    VerticalBarSeries,
    XAxis,
    YAxis,
} from 'react-vis';
import data from '../data/order_data.json';

import dataPricing from '../data/pricing_data.json';
import stylesOrders from '../styles/Orders.module.css';
import { useState } from 'react';

export default function Orders() {
    let dictionnary_pricing = Object.entries(dataPricing);

    let set_types = new Set(dictionnary_pricing.map((element) => {
        return element[0]
    }))

    let list_types = Array.from(set_types);


    let object_list_sizes = dictionnary_pricing.map((element) => {
        return element[1]
    })


    let list_sizes = Object.keys(Object.values(object_list_sizes)[0]);


    console.log(list_sizes);


    let data_orders_all_store = data.map((data) => ({
        store: data.store,
        nbItems: data.items.length
    }));

    let set_stores = new Set(data.map((data) => {
        return data.store
    }))

    let list_stores = Array.from(set_stores);

    //first default value
    const [finalData, setFinalData] = useState(Calculate_nb_orders_per_city(list_stores, data_orders_all_store));

    function Calculate_nb_orders_per_city(list_stores, data_orders_all_store) {
        let nbOrdersKanata = 0;
        let nbOrdersOrleans = 0;
        let nbOrdersDowntown = 0;
        let nbOrdersSandy_Hill = 0;
        let nbOrdersThe_Glebe = 0;

        for (let i = 0; i < list_stores.length; i++) {
            for (let j = 0; j < data_orders_all_store.length; j++) {
                if (data_orders_all_store[j].store === list_stores[i]) {
                    if (data_orders_all_store[j].store === "Kanata") {
                        nbOrdersKanata += data_orders_all_store[j].nbItems;
                    }
                    else if (data_orders_all_store[j].store === "Orleans") {
                        nbOrdersOrleans += data_orders_all_store[j].nbItems;
                    }
                    else if (data_orders_all_store[j].store === "Downtown") {
                        nbOrdersDowntown += data_orders_all_store[j].nbItems;
                    }
                    else if (data_orders_all_store[j].store === "Sandy Hill") {
                        nbOrdersSandy_Hill += data_orders_all_store[j].nbItems;
                    }
                    else if (data_orders_all_store[j].store === "The Glebe") {
                        nbOrdersThe_Glebe += data_orders_all_store[j].nbItems;
                    }
                }

            }
        }

        console.log("Kanata:" + nbOrdersKanata);
        console.log("Orleans:" + nbOrdersOrleans);
        console.log("Downtown:" + nbOrdersDowntown);
        console.log("Sandy Hill:" + nbOrdersSandy_Hill);
        console.log("The Glebe:" + nbOrdersThe_Glebe);

        let data = [
            { x: "Downtown", y: nbOrdersDowntown },
            { x: "Kanata", y: nbOrdersKanata },
            { x: "Orleans", y: nbOrdersOrleans },
            { x: "The Glebe", y: nbOrdersThe_Glebe },
            { x: "Sandy Hill", y: nbOrdersSandy_Hill }]

        return data;
    }

    function selectedType(event) {
        let selectedValue = event.currentTarget.value;
        console.log(selectedValue);
        let data_general = data.map((element) => ({
            store: element.store,
            items: element.items,
            date: element.date,
            order_id: element.order_id
        }));

        //if at least one type of pizza is present then filter it by item
        let data_types = data_general.filter(element => element.items.some(item => item.type === selectedValue))
        //I want this to be manipulate by my method Calculate_nb_orders_per_city 
        let data_types_orders = data_types.map((element) => ({
            store: element.store,
            nbItems: element.items.length,
            date:element.date
        }));

        let startDate = document.getElementById("startDate").value;
        let endDate = document.getElementById("endDate").value;

        console.log(data_types_orders);
        if (selectedValue === "") {
            //default value
            setFinalData(Calculate_nb_orders_per_city(list_stores, data_orders_all_store));
        }else if(startDate !== "" || endDate !==""){

            let data_orders_all_store_and_dates_filtered_by_date;
            
            let data_orders_all_store_and_dates = data_types_orders.map((data) => ({
                store: data.store,
                nbItems: data.nbItems,
                date:data.date
            }));
    
            if ((endDate === "" && startDate === "")) {
                data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates;
            } else if(endDate === ""){
                data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element)=> element.date >= startDate);
            }else if (startDate === "") {
                data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) => element.date <= endDate)
            } else {
                data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) =>element.date >= startDate && element.date <= endDate)
            }
    
            setFinalData(Calculate_nb_orders_per_city(list_stores, data_orders_all_store_and_dates_filtered_by_date))
    
    
            }  else {
            setFinalData(Calculate_nb_orders_per_city(list_stores, data_types_orders));
        }

    }
    function selectedSize(event) {
        let selectedValue = event.currentTarget.value;
        console.log(selectedValue);
        let data_general = data.map((element) => ({
            store: element.store,
            items: element.items,
            date: element.date,
            order_id: element.order_id
        }));

        //if at least one size of pizza is present then filter it by item
        let data_size = data_general.filter(element => element.items.some(item => item.size === selectedValue))

        //I want this to be manipulate by my method Calculate_nb_orders_per_city 
        let data_size_orders = data_size.map((element) => ({
            store: element.store,
            nbItems: element.items.length,
            date:element.date
        }));

        console.log(data_size_orders);

        let startDate = document.getElementById("startDate").value;
        let endDate = document.getElementById("endDate").value;

        if (selectedValue === "") {
            //default value
            setFinalData(Calculate_nb_orders_per_city(list_stores, data_orders_all_store));
        } else if(startDate !== "" || endDate !==""){

        let data_orders_all_store_and_dates_filtered_by_date;
        
        let data_orders_all_store_and_dates = data_size_orders.map((data) => ({
            store: data.store,
            nbItems: data.nbItems,
            date:data.date
        }));

        if ((endDate === "" && startDate === "")) {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates;
        } else if(endDate === ""){
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element)=> element.date >= startDate);
        }else if (startDate === "") {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) => element.date <= endDate)
        } else {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) =>element.date >= startDate && element.date <= endDate)
        }

        setFinalData(Calculate_nb_orders_per_city(list_stores, data_orders_all_store_and_dates_filtered_by_date))


        } else {
            setFinalData(Calculate_nb_orders_per_city(list_stores, data_size_orders));
        }
    }

    //******REMAINS to filter the filtered size and types by dates*******
    function filterDates() {
        let startDate = document.getElementById("startDate").value;
        let endDate = document.getElementById("endDate").value;
        let data_orders_all_store_and_dates_filtered_by_date;
        console.log("Start date:", startDate);
        console.log("End date:", endDate);
        
        let data_orders_all_store_and_dates = data.map((data) => ({
            store: data.store,
            nbItems: data.items.length,
            date:data.date
        }));
        if ((endDate === "" && startDate === "")) {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates;
        } else if(endDate === ""){
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element)=> element.date >= startDate);
        }else if (startDate === "") {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) => element.date <= endDate)
        } else {
            data_orders_all_store_and_dates_filtered_by_date = data_orders_all_store_and_dates.filter((element) =>element.date >= startDate && element.date <= endDate)
        }

        setFinalData(Calculate_nb_orders_per_city(list_stores, data_orders_all_store_and_dates_filtered_by_date))


    }
    

    //I found document.addEventListener(...) on stack overflow, it avoids the error of childAppend is null
    return (
        <>
            <main>
                <h1>Orders per store</h1>
                <div>
                    <select id="selectTypes" onChange={(event) => selectedType(event)}>
                        <option value="">Filter by type</option>
                        <option value={list_types[0]}>{list_types[0]}</option>
                        <option value={list_types[1]}>{list_types[1]}</option>
                        <option value={list_types[2]}>{list_types[2]}</option>
                        <option value={list_types[3]}>{list_types[3]}</option>
                        <option value={list_types[4]}>{list_types[4]}</option>
                    </select>
                    <select id="selectSizes" onChange={(event) => selectedSize(event)}>
                        <option value="">Filter by size</option>
                        <option value={list_sizes[0]}>{list_sizes[0]}</option>
                        <option value={list_sizes[1]}>{list_sizes[1]}</option>
                        <option value={list_sizes[2]}>{list_sizes[2]}</option>
                    </select>
                </div>
                <div>
                    <form>
                        <label htmlFor="startDate">Start date :</label>
                        <input type="date" id="startDate" name="startDate" />

                        <label htmlFor="endDate">End date :</label>
                        <input type="date" id="endDate" name="endDate" />

                        <button type="button" onClick={filterDates} >Filter</button>
                    </form>
                </div>
                <XYPlot xType='ordinal'
                    width={600}
                    height={400}>
                    <VerticalBarSeries className={stylesOrders.Vertical_Bar_Series}
                        data={finalData}
                    />
                    <YAxis></YAxis>
                    <XAxis></XAxis>
                </XYPlot>
            </main>
        </>
    )
}