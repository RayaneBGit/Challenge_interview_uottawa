import Head from "next/head"

import React from 'react';
export default function NotFound() {
    return <>
        <Head>
            <title>Error 404</title>
        </Head>
        <div>404 | Not Found</div>
    </>
}