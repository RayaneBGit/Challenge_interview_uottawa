import stylesLayout from '../styles/Layout.module.css';


export default function Footer() {

    return (<footer className={stylesLayout.footer}>
        <div>&copy; Copyright | Rayane Badaoui | University of Ottawa</div>
    </footer>)
}