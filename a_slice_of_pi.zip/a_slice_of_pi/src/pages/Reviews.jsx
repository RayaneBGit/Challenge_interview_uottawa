import React, { useState } from 'react';
import data from '../data/review_data.json';
import { RadialChart } from 'react-vis';
import styleReviews from '../styles/Reviews.module.css';

export default function Reviews() {

  const list_dates_and_sentiments = data.map((data) => ({
    date: data.date,
    sentiment: data.sentiment.charAt(0).toUpperCase() + data.sentiment.slice(1)
  }))

  console.log(list_dates_and_sentiments);

  const listSentimentsBig = data.map((data) => {
    return data.sentiment.charAt(0).toUpperCase() + data.sentiment.slice(1)
  })
  console.log(listSentimentsBig)

  const SentimentsSet = new Set(data.map((data) => {
    return data.sentiment.charAt(0).toUpperCase() + data.sentiment.slice(1)
  }))

  let SentimentsList = Array.from(SentimentsSet);

  //put in order the sentiments to be easier in managing coding
  SentimentsList.sort()
  console.log(SentimentsList)

  function calculate_sentiments(SentimentsList, listSentimentsBig) {
    let nbAngry = 0;
    let nbSad = 0;
    let nbDelighted = 0;
    let nbHappy = 0;

    for (let i = 0; i < SentimentsList.length; i++) {
      for (let j = 0; j < listSentimentsBig.length; j++) {
        if (listSentimentsBig[j] === SentimentsList[i]
          && SentimentsList[i] === "Angry") {
          nbAngry++;
        } else if (listSentimentsBig[j] === SentimentsList[i]
          && SentimentsList[i] === "Sad") {
          nbSad++
        } else if (listSentimentsBig[j] === SentimentsList[i]
          && SentimentsList[i] === "Delighted") {
          nbDelighted++
        } else if (listSentimentsBig[j] === SentimentsList[i]
          && SentimentsList[i] === "Happy") {
          nbHappy++
        }
      }
    }

    return [nbAngry, nbDelighted, nbHappy, nbSad];
  }
  let sentimentsdata = calculate_sentiments(SentimentsList, listSentimentsBig);

  const chartdata = [
    { angle: sentimentsdata[0], color: "#FFD556", label: sentimentsdata[0] + String.fromCodePoint(0x1F621) },
    { angle: sentimentsdata[1], color: '#FFD556', label: sentimentsdata[1] + String.fromCodePoint(0x1F642) },
    { angle: sentimentsdata[2], color: '#FFD556', label: sentimentsdata[2] + String.fromCodePoint(0x1F601) },
    { angle: sentimentsdata[3], color: '#FFD556', label: sentimentsdata[3] + String.fromCodePoint(128557) }
  ];

  //first default value
  const [finalData, setFinalData] = useState(chartdata);

  function filterDates() {
    //if its default value of date or not

    let startDate = document.getElementById("startDate").value;
    let endDate = document.getElementById("endDate").value;

    let list_dates_and_sentiments_filtered_by_dates;

    if ((endDate === "" && startDate === "")) {
      list_dates_and_sentiments_filtered_by_dates = list_dates_and_sentiments;
    } else if (startDate === "") {
      list_dates_and_sentiments_filtered_by_dates = list_dates_and_sentiments.filter((element) => element.date <= endDate)
    } else if (endDate === "") {
      list_dates_and_sentiments_filtered_by_dates = list_dates_and_sentiments.filter((element) => element.date >= startDate)
    } 
    else {
      list_dates_and_sentiments_filtered_by_dates = list_dates_and_sentiments.filter((element) => element.date >= startDate && element.date <= endDate)
    }
    console.log(list_dates_and_sentiments_filtered_by_dates);


    let listSentiments_filtered_by_dates = list_dates_and_sentiments_filtered_by_dates.map((element) => {
      return element.sentiment;
    })

    let sentimentsdata = calculate_sentiments(SentimentsList, listSentiments_filtered_by_dates);

    setFinalData([
      { angle: sentimentsdata[0], color: "#FFD556", label: sentimentsdata[0] + String.fromCodePoint(0x1F621) },
      { angle: sentimentsdata[1], color: '#FFD556', label: sentimentsdata[1] + String.fromCodePoint(0x1F642) },
      { angle: sentimentsdata[2], color: '#FFD556', label: sentimentsdata[2] + String.fromCodePoint(0x1F601) },
      { angle: sentimentsdata[3], color: '#FFD556', label: sentimentsdata[3] + String.fromCodePoint(128557) }
    ]);

  }



  //   const colorDifferents = ['#0003213', '#00ff00', '#0000ff']; // Définissez vos couleurs ici
  return <>
    <main>
      <h1>Reviews</h1>

      <form>
        <label htmlFor="startDate">Start date :</label>
        <input type="date" id="startDate" name="startDate" />

        <label htmlFor="endDate">End date :</label>
        <input type="date" id="endDate" name="endDate" />

        <button type="button" onClick={filterDates}>Filter</button>
      </form>

      <RadialChart
        className={styleReviews.radial_chart}
        data={finalData}
        width={400}
        height={400}
        colorType="literal"
        colorDomain={[0, 1, 2]}
        showLabels
        // Color border
        stroke="white"
        // Size border
        strokeWidth={2}
        //en bas c pour qu il soit bien positionné
        labelsAboveChildren />

      <h2>Legend</h2>
      <div className={styleReviews.legend}>
        <p>{String.fromCodePoint(0x1F621)} Angry</p>
        <p>{String.fromCodePoint(0x1F642)} Delighted</p>
        <p>{String.fromCodePoint(0x1F601)} Happy</p>
        <p>{String.fromCodePoint(128557)} Sad</p>
      </div>
    </main>
  </>
}