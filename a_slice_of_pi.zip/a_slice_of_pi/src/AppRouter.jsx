import React from "react";
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Reviews from './pages/Reviews';
import Header from './components/Header'
import Footer from './components/Footer'
import Orders from "./pages/Orders";
import Pricing from "./pages/Pricing";
export default function AppRouter ()  {
    return <>
    <Header></Header>
    <Routes>
        <Route path="/" exact element={<Home/>}></Route>
        <Route path="/Reviews" element={<Reviews/>}></Route>
        <Route path="/Orders" element={<Orders/>}></Route>
        <Route path="/Pricing" element={<Pricing/>}></Route>
    </Routes>
    <Footer></Footer>
    </>
}